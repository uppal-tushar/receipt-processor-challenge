using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using ReceiptProcessor_API.BusinessLayer;
using ReceiptProcessor_API.DataAccessLayer;

namespace ReceiptProcessor_API
{
    public class Startup

    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

     
        public void ConfigureServices(IServiceCollection services)
        {
            _ = services.AddOptions();

            services.AddMemoryCache();

           

            _ = services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.SetIsOriginAllowed(_ => true)
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials());
            });

            DependencyInjection(services);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("receipt-processor", new OpenApiInfo
                {
                    Title = "ReceiptProcessor API ",
                    Version = ApiVersion.Default.ToString()
                });
                c.CustomSchemaIds(x => x.FullName);
            });

            _ = services.AddControllers()
                .AddNewtonsoftJson(
                    options =>
                        options.SerializerSettings.ContractResolver = new
                            CamelCasePropertyNamesContractResolver()).AddJsonOptions(options => options.JsonSerializerOptions.PropertyNameCaseInsensitive = true);
        }

        private void DependencyInjection(IServiceCollection services)
        {
            services.AddScoped<IReceiptProcessor, ReceiptProcessor>();
            services.AddScoped<IReceiptProcessorService, ReceiptProcessorService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IHostApplicationLifetime lifeTime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            lifeTime.ApplicationStopping.Register(() =>
            {
                Console.WriteLine("Application Stopping");
            });

            lifeTime.ApplicationStarted.Register(() =>
            {
                Console.WriteLine("Application Started");
            });

            _ = app.UseCors("CorsPolicy");

            app.UseSwagger();
            app.UseSwaggerUI(u =>
            {
                u.SwaggerEndpoint("../swagger/receipt-processor/swagger.json", "receipt-processor");
            });
            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
