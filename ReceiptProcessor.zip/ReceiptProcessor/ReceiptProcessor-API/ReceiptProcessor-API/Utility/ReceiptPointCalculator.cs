﻿using ReceiptProcessor_API.Models.Request;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace ReceiptProcessor_API.Utility
{
    public class ReceiptPointCalculator
    {
        public static double ProcessReceipt(ReceiptRequest receiptRequest)
        {
            var totalPoints = 0.0;
            totalPoints += CheckAlphaNumeric(receiptRequest.Retailer);
            totalPoints += CheckRoundDollarAmount(receiptRequest.Total);
            totalPoints += CheckIsMultiple(receiptRequest.Total);
            totalPoints += CheckEveryTwoItems(receiptRequest.Items.Count);
            totalPoints += CheckItemsLength(receiptRequest.Items);
            totalPoints += CheckOddDays(receiptRequest.PurchaseDate);
            totalPoints += CheckTime(receiptRequest.PurchaseTime);
            return totalPoints;
        }

        private static double CheckTime(string purchaseTime)
        {
            var tm = new DateTime();
            var timeSpan = DateTime.TryParse(purchaseTime, out tm);
            var startDt = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 14, 0, 0);
            var endDt = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day, 16, 0, 0);
            if (tm > startDt && tm < endDt)
            {
                return 10;
            }
            return default;
        }

        private static double CheckOddDays(string purchaseDate)
        {
            var date = DateTime.ParseExact(purchaseDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            if (date.Day % 2 != 0)
            {
                return 6;
            }

            return default;
        }

        private static double CheckItemsLength(List<Items> productItems)
        {
            var count = 0.0;
            foreach (var items in productItems)
            {
                var descLength = items.ShortDescription.Length;
                if (descLength % 3 == 0)
                {
                    var ct= Convert.ToDouble(items.Price) * 0.2;
                    count += Math.Round(ct,MidpointRounding.ToPositiveInfinity);
                }
            }

            return count;
        }

        private static double CheckEveryTwoItems(int count)
        {
            var totalTwoItems = count / 2;
            return totalTwoItems * 5;
        }

        private static double CheckIsMultiple(string total)
        {
            var amount = Convert.ToDouble(total);
            if (amount % 0.25 == 0)
            {
                return 25;
            }

            return 0;
        }

        private static double CheckRoundDollarAmount(string total)
        {
            var amount = Convert.ToDouble(total);
            if (amount % 1 == 0)
            {
                return 50;
            }

            return default;
        }

        private static double CheckAlphaNumeric(string retailer)
        {
            var count = 0;
            if (string.IsNullOrWhiteSpace(retailer))
                return default;
            var retailersWithoutSpace = new string(retailer.ToCharArray().Where(c => !char.IsWhiteSpace(c)).ToArray());
            for (int i = 0; i < retailersWithoutSpace.Length; i++)
            {
                if (char.IsLetterOrDigit(retailersWithoutSpace, i))
                {
                    count++;
                }
            }
            return count;
        }
    }
}
