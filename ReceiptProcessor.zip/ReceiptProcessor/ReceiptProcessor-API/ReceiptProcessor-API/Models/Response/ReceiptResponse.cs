﻿using System.Collections.Generic;

namespace ReceiptProcessor_API.Models.Response
{
    public class ReceiptResponse
    {
        public string Id { get; set; }

    }
}
