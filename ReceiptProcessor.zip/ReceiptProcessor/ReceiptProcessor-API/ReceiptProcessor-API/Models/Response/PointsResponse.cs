﻿namespace ReceiptProcessor_API.Models.Response
{
    public class PointsResponse
    {
        public double Points { get; set; }
    }
}
