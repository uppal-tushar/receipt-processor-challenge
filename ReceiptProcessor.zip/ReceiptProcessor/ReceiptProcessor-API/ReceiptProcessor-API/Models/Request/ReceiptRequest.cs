﻿using System.Collections.Generic;

namespace ReceiptProcessor_API.Models.Request
{
    public class ReceiptRequest
    {
        public string Retailer { get; set; }
        public string PurchaseDate { get; set; }
        public string PurchaseTime { get; set; }
        public List<Items> Items { get; set; }
        public string Total { get; set; }
    }

    public class Items
    {
        public string ShortDescription { get; set; }
        public string Price { get; set; }
    }

}
