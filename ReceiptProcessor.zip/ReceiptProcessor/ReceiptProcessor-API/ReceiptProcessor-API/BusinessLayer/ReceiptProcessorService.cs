﻿using ReceiptProcessor_API.DataAccessLayer;
using ReceiptProcessor_API.Models.Request;
using ReceiptProcessor_API.Models.Response;
using ReceiptProcessor_API.Utility;

namespace ReceiptProcessor_API.BusinessLayer
{
    public class ReceiptProcessorService : IReceiptProcessorService
    {
        public IReceiptProcessor _receiptProcessor;

        public ReceiptProcessorService(IReceiptProcessor receiptProcessor)
        {
            _receiptProcessor = receiptProcessor;
        }

        public ReceiptResponse ProcessReceiptAsync(ReceiptRequest receiptRequest)
        {
            var calculatePoints = ReceiptPointCalculator.ProcessReceipt(receiptRequest);
            return _receiptProcessor.StoreReceiptDetails(calculatePoints);
        }
        
        public PointsResponse GetPointsAsync(string id)
        {
            return _receiptProcessor.GetPointsAsync(id);
        }
    }
}
