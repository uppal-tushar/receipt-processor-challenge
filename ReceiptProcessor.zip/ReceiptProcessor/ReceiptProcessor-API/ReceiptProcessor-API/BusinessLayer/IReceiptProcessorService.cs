﻿using ReceiptProcessor_API.Models.Request;
using ReceiptProcessor_API.Models.Response;

namespace ReceiptProcessor_API.BusinessLayer
{
    public interface IReceiptProcessorService
    {
        ReceiptResponse ProcessReceiptAsync(ReceiptRequest receiptRequest);
        PointsResponse GetPointsAsync(string id);
    }
}
