﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ReceiptProcessor_API.BusinessLayer;
using ReceiptProcessor_API.Models.Request;
using ReceiptProcessor_API.Models.Response;

namespace ReceiptProcessor_API.Controllers
{
    //[ApiVersion("1.0")]
    [Route("api/[controller]")]
    [ApiController]
    public class ReceiptProcessorController : ControllerBase
    {
        private readonly IReceiptProcessorService _receiptProcessorService;

        public ReceiptProcessorController(IReceiptProcessorService receiptProcessorService)
        {
            _receiptProcessorService = receiptProcessorService;
        }

        [Route("receipts/process")]
        [HttpPost]
        public async Task<IActionResult> ProcessReceiptAsync([FromBody] ReceiptRequest receiptRequest)
        {
            try
            {
                var processReceiptResponse = _receiptProcessorService.ProcessReceiptAsync(receiptRequest);
                return StatusCode((int)HttpStatusCode.OK, processReceiptResponse);
            }
            catch (Exception e)
            {
                var processReceiptResponse = new ReceiptResponse();
                return StatusCode((int)HttpStatusCode.BadRequest, processReceiptResponse);
            }
        }

        [Route("receipts/{id}/points")]
        [HttpGet]
        public async Task<IActionResult> GetPointsAsync(string id)
        {
            try
            {
                var processReceiptResponse = _receiptProcessorService.GetPointsAsync(id);
                return StatusCode((int)HttpStatusCode.OK, processReceiptResponse);
            }
            catch (Exception e)
            {
                var processReceiptResponse = new ReceiptResponse();
                return StatusCode((int)HttpStatusCode.BadRequest, processReceiptResponse);
            }
        }
    }
}
