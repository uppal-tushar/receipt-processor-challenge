﻿using ReceiptProcessor_API.Models.Response;

namespace ReceiptProcessor_API.DataAccessLayer
{
    public interface IReceiptProcessor
    {
        ReceiptResponse StoreReceiptDetails(double points);
        PointsResponse GetPointsAsync(string id);
    }
}
