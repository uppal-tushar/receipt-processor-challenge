﻿using ReceiptProcessor_API.Models.Request;
using ReceiptProcessor_API.Models.Response;
using System;
using Microsoft.Extensions.Caching.Memory;

namespace ReceiptProcessor_API.DataAccessLayer
{
    public class ReceiptProcessor : IReceiptProcessor
    {
        private readonly IMemoryCache _memoryCache;
        public ReceiptProcessor(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public ReceiptResponse StoreReceiptDetails(double points)
        {
            var cacheExpiryOptions = new MemoryCacheEntryOptions()
            {
                AbsoluteExpiration = DateTime.Now.AddHours(4),
                Priority = CacheItemPriority.High
            };
            var id = Guid.NewGuid().ToString();
            this._memoryCache.Set(id, points, cacheExpiryOptions);
            return new ReceiptResponse() { Id = id };
        }

        public PointsResponse GetPointsAsync(string id)
        {
            double points;
            this._memoryCache.TryGetValue(id, out points);
            return new PointsResponse() { Points = points };
        }
    }
}
